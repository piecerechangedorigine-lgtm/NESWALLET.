package com.novafinance.feature.assistant.navigation

import com.novafinance.core.navigation.NovaNavGraphProvider
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet

@Module
@InstallIn(SingletonComponent::class)
abstract class AssistantNavModule {

    @Binds
    @IntoSet
    abstract fun bindAssistantNavGraphProvider(
        impl: AssistantNavGraphProvider
    ): NovaNavGraphProvider
}
